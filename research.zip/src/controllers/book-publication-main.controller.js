module.exports.renderBookPublication = async(req, res, next) => {
    res.render('book-publication-main')
}