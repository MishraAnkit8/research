module.exports.renderDashboard = async (req, res, next) => {
    res.render('dashboard');
};

