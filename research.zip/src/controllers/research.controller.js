module.exports.renderResearch = async (req, res, next) => {
    res.render('research');
};

