module.exports = {
    includeHtml (val) {
        console.log('val => ', val);
        return val;
    }
};